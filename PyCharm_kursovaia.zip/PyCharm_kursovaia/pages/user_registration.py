from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Label, Frame
from tkinter.messagebox import showerror, showinfo
from internal.database import DatabaseManager
from internal.validation import *
import functions


def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame3/" + path

def open_user_registration_window(window):
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 400,
        width = 400,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        262.0,
        21.0,
        image=image_image_1
    )

    canvas.create_text(
        14.0,
        8.0,
        anchor="nw",
        text="Регистрация",
        fill="#E19A17",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        7.0,
        75.0,
        anchor="nw",
        text="Ф.И.О.",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        3.0,
        107.0,
        anchor="nw",
        text="Номер телефона",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        8.0,
        139.0,
        anchor="nw",
        text="Адрес",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 15 * -1)
    )

    canvas.create_text(
        3.0,
        171.0,
        anchor="nw",
        text="Дата рождения",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_rectangle(
        16.0,
        59.0,
        135.0,
        60.0,
        fill="#000000",
        outline="")

    canvas.create_text(
        140.0,
        49.0,
        anchor="nw",
        text="Личные данные",
        fill="#000000",
        font=("PlayfairDisplay Italic", 13 * -1)
    )

    canvas.create_rectangle(
        265.0,
        59.0,
        384.0,
        60.0,
        fill="#000000",
        outline="")

    entry_image_1 = PhotoImage(
        file=relative_to_assets("entry_1.png"))
    canvas.entry_image_1 = entry_image_1
    entry_bg_1 = canvas.create_image(
        221.5,
        89.5,
        image=entry_image_1
    )
    entry_1 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_1.place(
        x=73.0,
        y=79.0,
        width=297.0,
        height=19.0
    )

    entry_image_2 = PhotoImage(
        file=relative_to_assets("entry_2.png"))
    canvas.entry_image_2 = entry_image_2
    entry_bg_2 = canvas.create_image(
        262.5,
        120.5,
        image=entry_image_2
    )
    entry_2 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_2.place(
        x=155.0,
        y=110.0,
        width=215.0,
        height=19.0
    )

    entry_image_3 = PhotoImage(
        file=relative_to_assets("entry_3.png"))
    canvas.entry_image_3 = entry_image_3
    entry_bg_3 = canvas.create_image(
        218.0,
        150.5,
        image=entry_image_3
    )
    entry_3 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_3.place(
        x=66.0,
        y=140.0,
        width=304.0,
        height=19.0
    )

    canvas.create_text(
        0.0,
        202.0,
        anchor="nw",
        text="Электронная почта",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    entry_image_4 = PhotoImage(
        file=relative_to_assets("entry_4.png"))
    canvas.entry_image_4 = entry_image_4
    entry_bg_4 = canvas.create_image(
        257.0,
        181.5,
        image=entry_image_4
    )
    entry_4 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_4.place(
        x=144.0,
        y=171.0,
        width=226.0,
        height=19.0
    )

    entry_image_5 = PhotoImage(
        file=relative_to_assets("entry_5.png"))
    canvas.entry_image_5 = entry_image_5
    entry_bg_5 = canvas.create_image(
        275.5,
        212.5,
        image=entry_image_5
    )
    entry_5 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_5.place(
        x=181.0,
        y=202.0,
        width=189.0,
        height=19.0
    )

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: registrate(window, entry_1.get(), entry_2.get(), entry_3.get(), entry_4.get(), entry_5.get(), entry_6.get(), entry_7.get()),
        relief="flat"
    )
    button_1.place(
        x=205.0,
        y=349.0,
        width=178.0,
        height=39.0
    )

    canvas.create_rectangle(
        15.0,
        260.0,
        134.0,
        261.0,
        fill="#000000",
        outline="")

    canvas.create_text(
        139.0,
        250.0,
        anchor="nw",
        text="Безопасность",
        fill="#000000",
        font=("PlayfairDisplay Italic", 13 * -1)
    )

    canvas.create_rectangle(
        264.0,
        260.0,
        383.0,
        261.0,
        fill="#000000",
        outline="")

    canvas.create_text(
        0.0,
        274.0,
        anchor="nw",
        text="Логин",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        10.0,
        306.0,
        anchor="nw",
        text="Пароль",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    entry_image_6 = PhotoImage(
        file=relative_to_assets("entry_6.png"))
    canvas.entry_image_6 = entry_image_6
    entry_bg_6 = canvas.create_image(
        228.5,
        288.5,
        image=entry_image_6
    )
    entry_6 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_6.place(
        x=80.0,
        y=278.0,
        width=297.0,
        height=19.0
    )

    entry_image_7 = PhotoImage(
        file=relative_to_assets("entry_7.png"))
    canvas.entry_image_7 = entry_image_7
    entry_bg_7 = canvas.create_image(
        230.0,
        319.5,
        image=entry_image_7
    )
    entry_7 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_7.place(
        x=83.0,
        y=309.0,
        width=294.0,
        height=19.0
    )

def registrate(window, fio, phone, address, birthday, email, login, password):
    if not validate_phone(phone):
        showerror(title="Информация", message="Введите номер телефона в формате +70123456789")
        return
    if not validate_email(email):
        showerror(title="Информация", message="Введите почтовый адрес в формате email@email.ru")
        return
    if not validate_birthday(birthday):
        showerror(title="Информация", message="Введите дату рождения в формате ДД.ММ.ГГГГ")
        return
    if not all([fio, phone, address, birthday, email, login, password]):
        label = Label(text="Вы не заполнили одно из полей")
        label.pack()
    
    else:
        db = DatabaseManager("database/db.db")
        try:
            db.execute(f"INSERT INTO users (login, password, is_auth) VALUES ('{login}', '{password}', {1})")
        except Exception as E:
            showerror(title="Информация", message="Логин уже существует")
            return
        try:
            user_id = db.query(f"SELECT id FROM users WHERE login = '{login}' LIMIT 1")[0][0]
            db.execute(f"INSERT INTO users_info (user_id, name, phone, address, birthday, email) VALUES ('{user_id}', '{fio}', '{phone}', '{address}', '{birthday}', '{email}')")
        except Exception as E:
            showerror(title="Информация", message="Ошибка при работе с БД")
            return
        functions.show_dayly_tarifes(window)
