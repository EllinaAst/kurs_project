from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame
import functions


def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame5/" + path

def open_user_dayly_tarifes(window):
    window.geometry("517x470")
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 470,
        width = 517,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        311.0,
        33.0,
        image=image_image_1
    )

    canvas.create_text(
        27.0,
        0.0,
        anchor="nw",
        text="Тарифные планы",
        fill="#E19A17",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_rectangle(
        18.0,
        96.0,
        162.0,
        237.0,
        fill="#F1E9F3",
        outline="")

    canvas.create_rectangle(
        187.0,
        96.0,
        332.0,
        237.0,
        fill="#F1E9F4",
        outline="")

    canvas.create_rectangle(
        357.0,
        96.0,
        501.0,
        237.0,
        fill="#F1E9F3",
        outline="")

    canvas.create_rectangle(
        18.0,
        270.0,
        162.0,
        411.0,
        fill="#F1E9F3",
        outline="")

    canvas.create_rectangle(
        187.0,
        270.0,
        332.0,
        411.0,
        fill="#F1E9F3",
        outline="")

    canvas.create_rectangle(
        357.0,
        270.0,
        501.0,
        411.0,
        fill="#F1E9F3",
        outline="")

    canvas.create_rectangle(
        32.0,
        103.0,
        148.0,
        124.0,
        fill="#6A3A76",
        outline="")

    canvas.create_text(
        34.0,
        103.0,
        anchor="nw",
        text="«Выгодный»",
        fill="#FFFCFC",
        font=("PlayfairDisplay SemiBold", 12 * -1)
    )

    image_image_2 = PhotoImage(
        file=relative_to_assets("image_2.png"))
    canvas.image_image_2 = image_image_2
    image_2 = canvas.create_image(
        89.0,
        172.0,
        image=image_image_2
    )

    image_image_3 = PhotoImage(
        file=relative_to_assets("image_3.png"))
    canvas.image_image_3 = image_image_3
    image_3 = canvas.create_image(
        256.0,
        343.0,
        image=image_image_3
    )

    canvas.create_rectangle(
        195.0,
        103.0,
        325.0,
        124.0,
        fill="#6A3A76",
        outline="")

    canvas.create_text(
        197.0,
        103.0,
        anchor="nw",
        text="«Оптимальный»",
        fill="#FFFCFC",
        font=("PlayfairDisplay SemiBold", 12 * -1)
    )

    image_image_4 = PhotoImage(
        file=relative_to_assets("image_4.png"))
    canvas.image_image_4 = image_image_4
    image_4 = canvas.create_image(
        429.0,
        170.0,
        image=image_image_4
    )

    canvas.create_rectangle(
        371.0,
        103.0,
        487.0,
        124.0,
        fill="#6A3A76",
        outline="")

    canvas.create_text(
        373.0,
        103.0,
        anchor="nw",
        text="«Семейный»",
        fill="#FFFCFC",
        font=("PlayfairDisplay SemiBold", 12 * -1)
    )

    canvas.create_rectangle(
        32.0,
        275.0,
        148.0,
        296.0,
        fill="#6A3A76",
        outline="")

    canvas.create_text(
        34.0,
        275.0,
        anchor="nw",
        text="«Новогодний»",
        fill="#FFFCFC",
        font=("PlayfairDisplay SemiBold", 12 * -1)
    )

    image_image_5 = PhotoImage(
        file=relative_to_assets("image_5.png"))
    canvas.image_image_5 = image_image_5
    image_5 = canvas.create_image(
        260.0,
        175.0,
        image=image_image_5
    )

    canvas.create_rectangle(
        194.0,
        275.0,
        325.0,
        296.0,
        fill="#6A3A76",
        outline="")

    canvas.create_text(
        197.0,
        275.0,
        anchor="nw",
        text="«Супер»",
        fill="#FFFCFC",
        font=("PlayfairDisplay SemiBold", 12 * -1)
    )

    image_image_6 = PhotoImage(
        file=relative_to_assets("image_6.png"))
    canvas.image_image_6 = image_image_6
    image_6 = canvas.create_image(
        429.0,
        347.0,
        image=image_image_6
    )

    canvas.create_rectangle(
        364.0,
        275.0,
        495.0,
        296.0,
        fill="#6A3A76",
        outline="")

    canvas.create_text(
        366.0,
        275.0,
        anchor="nw",
        text="«Самое нужное»",
        fill="#FFFCFC",
        font=("PlayfairDisplay SemiBold", 12 * -1)
    )

    image_image_7 = PhotoImage(
        file=relative_to_assets("image_7.png"))
    canvas.image_image_7 = image_image_7
    image_7 = canvas.create_image(
        89.0,
        345.0,
        image=image_image_7
    )

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.enter_tarif(window, "Выгодный"),
        relief="flat"
    )
    button_1.place(
        x=50.0,
        y=221.0,
        width=82.0,
        height=13.0
    )

    button_image_2 = PhotoImage(
        file=relative_to_assets("button_2.png"))
    canvas.button_image_2 = button_image_2
    button_2 = Button(
        image=button_image_2,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.enter_tarif(window, "Оптимальный"),
        relief="flat"
    )
    button_2.place(
        x=219.0,
        y=221.0,
        width=81.0,
        height=13.0
    )


    button_3.place(
        x=389.0,
        y=221.0,
        width=82.0,
        height=13.0
    )

    button_image_4 = PhotoImage(
        file=relative_to_assets("button_4.png"))
    canvas.button_image_4 = button_image_4
    button_4 = Button(
        image=button_image_4,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.enter_tarif(window, "Самое нужное"),
        relief="flat"
    )
    button_4.place(
        x=393.0,
        y=394.0,
        width=82.0,
        height=13.0
    )

    button_image_5 = PhotoImage(
        file=relative_to_assets("button_5.png"))
    canvas.button_image_5 = button_image_5
    button_5 = Button(
        image=button_image_5,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.enter_tarif(window, "Супер"),
        relief="flat"
    )
    button_5.place(
        x=216.0,
        y=394.0,
        width=82.0,
        height=13.0
    )

    button_image_6 = PhotoImage(
        file=relative_to_assets("button_6.png"))
    canvas.button_image_6 = button_image_6
    button_6 = Button(
        image=button_image_6,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.enter_tarif(window, "Новогодний"),
        relief="flat"
    )
    button_6.place(
        x=50.0,
        y=394.0,
        width=82.0,
        height=13.0
    )


    canvas.create_text(
        53.0,
        252.0,
        anchor="nw",
        text="399₽/мес",
        fill="#000000",
        font=("Play Regular", 15 * -1)
    )

    canvas.create_text(
        47.0,
        79.0,
        anchor="nw",
        text="350₽/мес",
        fill="#000000",
        font=("Play Regular", 15 * -1)
    )

    canvas.create_text(
        219.0,
        79.0,
        anchor="nw",
        text="299₽/мес",
        fill="#000000",
        font=("Play Regular", 15 * -1)
    )

    canvas.create_text(
        219.0,
        254.0,
        anchor="nw",
        text="600₽/мес",
        fill="#000000",
        font=("Play Regular", 15 * -1)
    )

    canvas.create_text(
        379.0,
        79.0,
        anchor="nw",
        text="1100₽/мес",
        fill="#000000",
        font=("Play Regular", 15 * -1)
    )

    canvas.create_text(
        394.0,
        251.0,
        anchor="nw",
        text="200₽/мес",
        fill="#000000",
        font=("Play Regular", 15 * -1)
    )

    button_image_7 = PhotoImage(
        file=relative_to_assets("button_7.png"))
    canvas.button_image_7 = button_image_7
    button_7 = Button(
        image=button_image_7,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_all_tarifes(window),
        relief="flat"
    )
    button_7.place(
        x=351.0,
        y=419.0,
        width=159.0,
        height=38.0
    )

    canvas.create_text(
        127.0,
        38.0,
        anchor="nw",
        text="Предложения дня",
        fill="#000000",
        font=("PlayfairDisplaySC Black", 20 * -1)
    )

