from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame, END
from internal.database import DatabaseManager
import functions

def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame10/" + path

def open_admin_find_abonent_form(window):
    global entry_1, entry_3, entry_4, entry_5
    window.geometry("400x400")
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 400,
        width = 400,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        262.0,
        21.0,
        image=image_image_1
    )

    canvas.create_text(
        14.0,
        8.0,
        anchor="nw",
        text="Абоненты",
        fill="#E19A17",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        1.0,
        180.0,
        anchor="nw",
        text="Ф.И.О.",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        10.0,
        74.0,
        anchor="nw",
        text="Номер телефона",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        0.0,
        212.0,
        anchor="nw",
        text="Адрес",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 15 * -1)
    )

    canvas.create_text(
        11.0,
        244.0,
        anchor="nw",
        text="Дата рождения",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_rectangle(
        13.0,
        167.0,
        132.0,
        168.0,
        fill="#000000",
        outline="")

    canvas.create_text(
        137.0,
        157.0,
        anchor="nw",
        text="Личные данные",
        fill="#000000",
        font=("PlayfairDisplay Italic", 13 * -1)
    )

    canvas.create_rectangle(
        262.0,
        167.0,
        381.0,
        168.0,
        fill="#000000",
        outline="")

    entry_image_1 = PhotoImage(
        file=relative_to_assets("entry_1.png"))
    canvas.entry_image_1 = entry_image_1
    entry_bg_1 = canvas.create_image(
        229.5,
        194.5,
        image=entry_image_1
    )
    entry_1 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_1.place(
        x=81.0,
        y=184.0,
        width=297.0,
        height=19.0
    )

    entry_image_2 = PhotoImage(
        file=relative_to_assets("entry_2.png"))
    canvas.entry_image_2 = entry_image_2
    entry_bg_2 = canvas.create_image(
        269.5,
        87.5,
        image=entry_image_2
    )
    entry_2 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_2.place(
        x=162.0,
        y=77.0,
        width=215.0,
        height=19.0
    )

    entry_image_3 = PhotoImage(
        file=relative_to_assets("entry_3.png"))
    canvas.entry_image_3 = entry_image_3
    entry_bg_3 = canvas.create_image(
        226.0,
        223.5,
        image=entry_image_3
    )
    entry_3 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_3.place(
        x=74.0,
        y=213.0,
        width=304.0,
        height=19.0
    )

    canvas.create_text(
        7.0,
        273.0,
        anchor="nw",
        text="Электронная почта",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    entry_image_4 = PhotoImage(
        file=relative_to_assets("entry_4.png"))
    canvas.entry_image_4 = entry_image_4
    entry_bg_4 = canvas.create_image(
        265.0,
        254.5,
        image=entry_image_4
    )
    entry_4 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_4.place(
        x=152.0,
        y=244.0,
        width=226.0,
        height=19.0
    )

    entry_image_5 = PhotoImage(
        file=relative_to_assets("entry_5.png"))
    canvas.entry_image_5 = entry_image_5
    entry_bg_5 = canvas.create_image(
        283.5,
        285.5,
        image=entry_image_5
    )
    entry_5 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_5.place(
        x=189.0,
        y=275.0,
        width=189.0,
        height=19.0
    )

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: find_abonent(entry_2.get()),
        relief="flat"
    )
    button_1.place(
        x=135.0,
        y=113.0,
        width=120.0,
        height=23.0
    )

    button_image_2 = PhotoImage(
        file=relative_to_assets("button_2.png"))
    canvas.button_image_2 = button_image_2
    button_2 = Button(
        image=button_image_2,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_admin_settings(window),
        relief="flat"
    )
    button_2.place(
        x=270.0,
        y=366.0,
        width=117.0,
        height=17.0
    )

def find_abonent(phone):
    print(phone)
    db = DatabaseManager("database/db.db")
    user_info = db.query(f"SELECT * FROM users_info WHERE phone = '{phone}' LIMIT 1")
    if not user_info:
        print("no user")
        return
    else:
        entry_1.delete(0, END)
        entry_3.delete(0, END)
        entry_4.delete(0, END)
        entry_5.delete(0, END)

        entry_1.insert(0, user_info[0][2])
        entry_3.insert(0, user_info[0][3])
        entry_4.insert(0, user_info[0][4])
        entry_5.insert(0, user_info[0][5])