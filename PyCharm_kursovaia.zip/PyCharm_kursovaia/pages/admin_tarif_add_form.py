from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame
import functions


def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame9/" + path

def open_admin_abonent_add_form(window):
    window.geometry("400x400")
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 400,
        width = 400,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        262.0,
        21.0,
        image=image_image_1
    )

    canvas.create_text(
        13.0,
        9.0,
        anchor="nw",
        text="Новый тариф",
        fill="#E19A17",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        9.0,
        104.0,
        anchor="nw",
        text="Название",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        6.0,
        134.0,
        anchor="nw",
        text="Стоимость ",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        10.0,
        164.0,
        anchor="nw",
        text="Описание",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 15 * -1)
    )

    canvas.create_rectangle(
        10.0,
        59.0,
        120.0,
        60.0,
        fill="#000000",
        outline="")

    canvas.create_text(
        126.0,
        51.0,
        anchor="nw",
        text="Введите данные о новом тарифе",
        fill="#000000",
        font=("PlayfairDisplay Italic", 13 * -1)
    )

    canvas.create_rectangle(
        330.0,
        59.0,
        384.0,
        60.0,
        fill="#000000",
        outline="")

    entry_image_1 = PhotoImage(
        file=relative_to_assets("entry_1.png"))
    canvas.entry_image_1 = entry_image_1
    entry_bg_1 = canvas.create_image(
        239.0,
        114.5,
        image=entry_image_1
    )
    entry_1 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_1.place(
        x=106.0,
        y=104.0,
        width=266.0,
        height=19.0
    )

    entry_image_2 = PhotoImage(
        file=relative_to_assets("entry_2.png"))
    canvas.entry_image_2 = entry_image_2
    entry_bg_2 = canvas.create_image(
        241.5,
        144.5,
        image=entry_image_2
    )
    entry_2 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_2.place(
        x=111.0,
        y=134.0,
        width=261.0,
        height=19.0
    )

    entry_image_3 = PhotoImage(
        file=relative_to_assets("entry_3.png"))
    canvas.entry_image_3 = entry_image_3
    entry_bg_3 = canvas.create_image(
        236.5,
        202.0,
        image=entry_image_3
    )
    entry_3 = Entry(
        bd=0,
        bg="#F5ECE0",
        fg="#000716",
        highlightthickness=0
    )
    entry_3.place(
        x=101.0,
        y=165.0,
        width=271.0,
        height=72.0
    )

    button_image_2 = PhotoImage(
        file=relative_to_assets("button_2.png"))
    canvas.button_image_2 = button_image_2
    button_2 = Button(
        image=button_image_2,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.add_tarif(window, entry_1.get(), entry_2.get(), entry_3.get()),
        relief="flat"
    )
    button_2.place(
        x=239.0,
        y=335.0,
        width=154.0,
        height=26.0
    )

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_admin_settings(window),
        relief="flat"
    )
    button_1.place(
        x=267.0,
        y=373.0,
        width=117.0,
        height=17.0
    )
