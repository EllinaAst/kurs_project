import tkinter as tk
import functions


def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame0/" + path


def open_auth_window(window):
    for widget in window.winfo_children():
        widget.destroy()
    frame = tk.Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = tk.Canvas(
        frame,
        bg="#FDFFFE",
        height=400,
        width=400,
        bd=0,
        highlightthickness=0,
        relief="ridge"
    )

    canvas.place(x=0, y=0)
    image_image_1 = tk.PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        200.0,
        90.0,
        image=image_image_1
    )
    canvas.create_text(
        89.0,
        195.0,
        anchor="nw",
        text="Выберите вариант входа.",
        fill="#000000",
        font=("SofiaSansSemiCondensed SemiBoldItalic", 20 * -1)
    )

    button_image_1 = tk.PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = tk.Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.auth_as_user(window),
        relief="flat"
    )
    button_1.place(
        x=127.0,
        y=250.0,
        width=152.0,
        height=37.0
    )

    button_image_2 = tk.PhotoImage(
        file=relative_to_assets("button_2.png"))
    canvas.button_image_2 = button_image_2
    button_2 = tk.Button(
        image=button_image_2,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.auth_as_admin(window),
        relief="flat"
    )
    button_2.place(
        x=131.0,
        y=310.0,
        width=152.0,
        height=37.0
    )

