from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame, ttk
from internal.database import DatabaseManager
import functions


def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame7/" + path

def open_admin_all_abonents(window):
    window.geometry("800x285")
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 285,
        width = 800,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        139.99999999999756,
        21.00000000001591,
        image=image_image_1
    )

    image_image_2 = PhotoImage(
        file=relative_to_assets("image_2.png"))
    canvas.image_image_2 = image_image_2
    image_2 = canvas.create_image(
        330.0,
        22.0,
        image=image_image_2
    )

    columns = ("phone", "name", "address", "birthday", "email")
    treeview_frame = Frame(frame)
    treeview_frame.place(x=0, y=43)
    tree = ttk.Treeview(treeview_frame, columns=columns, show="headings", selectmode="browse", height=7)
    tree.pack(side="left", fill="both")
    tree.heading("name", text="Номер телефона")
    tree.heading("phone", text="ФИО")
    tree.heading("address", text="Адрес")
    tree.heading("birthday", text="Дата рождения")
    tree.heading("email", text="Электронная почта")
    tree.column("#1", width=190)
    tree.column("#2", width=110)
    tree.column("#3", width=170)
    tree.column("#4", width=105)
    tree.column("#5", width=180)
    scrollbar = ttk.Scrollbar(treeview_frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    db = DatabaseManager("database/db.db")
    users = db.query("SELECT * FROM users_info")
    for user in users:
        user = (user[2], user[3], user[4], user[5], user[6])
        tree.insert("", "end", values=user)

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_find_abonent_form(window),
        relief="flat"
    )
    button_1.place(
        x=340.0,
        y=223.0,
        width=154.0,
        height=26.0
    )

    button_image_2 = PhotoImage(
        file=relative_to_assets("button_2.png"))
    canvas.button_image_2 = button_image_2
    button_2 = Button(
        image=button_image_2,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_admin_settings(window),
        relief="flat"
    )
    button_2.place(
        x=356.0,
        y=262.0,
        width=117.0,
        height=17.0
    )

    button_image_3 = PhotoImage(
        file=relative_to_assets("button_3.png"))
    canvas.button_image_3 = button_image_3
    button_3 = Button(
        image=button_image_3,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: export_to_excel(),
        relief="flat"
    )
    button_3.place(
        x=5.0,
        y=240.0,
        width=100.0,
        height=20.0
    )

import sqlite3
from openpyxl import Workbook
from tkinter import filedialog, messagebox

def export_to_excel():
    """Exports data from the 'users_info' table in db.db to an Excel file."""
    try:
        file_path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel Files", "*.xlsx"), ("All Files", "*.*")],
            title="Save File As"
        )

        if not file_path:
            return

        conn = sqlite3.connect(r"C:\Users\user\Desktop\2024.12.10_profi_tkinter_po1\database\db.db")
        cursor = conn.cursor()

        # Query the 'users_info' table
        cursor.execute("""
            SELECT user_id, name, phone, address, birthday, email, tarif_id
            FROM users_info
        """)
        users_info = cursor.fetchall()

        if not users_info:
            messagebox.showinfo("Information", "Не найдено")
            conn.close()
            return

        wb = Workbook()
        ws = wb.active
        ws.title = "Users Info"

        headers = ["user_id", "name", "phone", "address", "birthday", "email", "tarif_id"]
        ws.append(headers)

        for user in users_info:
            ws.append(user)

        wb.save(file_path)
        conn.close()

        messagebox.showinfo("Успешно!", f"Данные экспортированы в {file_path}")

    except sqlite3.Error as e:
        messagebox.showerror("Ошибка!", f"Database error: {e}")
    except Exception as e:
        messagebox.showerror("Ошибка!", f"An error occurred: {e}")