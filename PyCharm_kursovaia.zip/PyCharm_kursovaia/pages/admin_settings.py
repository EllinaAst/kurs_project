from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame
import functions

def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame6/" + path

def open_admin_settings(window):
    window.geometry("400x285")
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 285,
        width = 400,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        113.0,
        146.0,
        image=image_image_1
    )

    image_image_2 = PhotoImage(
        file=relative_to_assets("image_2.png"))
    canvas.image_image_2 = image_image_2
    image_2 = canvas.create_image(
        139.9999999999975,
        21.00000000001591,
        image=image_image_2
    )

    image_image_3 = PhotoImage(
        file=relative_to_assets("image_3.png"))
    canvas.image_image_3 = image_image_3
    image_3 = canvas.create_image(
        356.0,
        22.0,
        image=image_image_3
    )

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_admin_all_tarifes(window),
        relief="flat"
    )
    button_1.place(
        x=240.0,
        y=85.0,
        width=154.0,
        height=26.0
    )

    button_image_2 = PhotoImage(
        file=relative_to_assets("button_2.png"))
    canvas.button_image_2 = button_image_2
    button_2 = Button(
        image=button_image_2,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_all_abonents(window),
        relief="flat"
    )
    button_2.place(
        x=240.0,
        y=128.0,
        width=154.0,
        height=26.0
    )
