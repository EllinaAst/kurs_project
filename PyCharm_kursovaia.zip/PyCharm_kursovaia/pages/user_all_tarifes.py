from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, ttk, Frame
from internal.database import DatabaseManager
import functions


def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame11/" + path


def open_user_all_tarifes(window):
    window.geometry("400x285")
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 285,
        width = 400,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        139.9999999999975,
        21.000000000015916,
        image=image_image_1
    )

    image_image_2 = PhotoImage(
        file=relative_to_assets("image_2.png"))
    canvas.image_image_2 = image_image_2
    image_2 = canvas.create_image(
        356.0,
        22.0,
        image=image_image_2
    )

    columns = ("name", "price", "description")
    treeview_frame = Frame(frame)
    treeview_frame.place(x=0, y=43)
    tree = ttk.Treeview(treeview_frame, columns=columns, show="headings", selectmode="browse", height=9)
    tree.pack(side="left", fill="both")
    tree.heading("name", text="Название")
    tree.heading("price", text="Стоимость, руб/мес")
    tree.heading("description", text="Описание")
    tree.column("#1", width=126)
    tree.column("#2", width=126)
    tree.column("#3", width=126)
    scrollbar = ttk.Scrollbar(treeview_frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    db = DatabaseManager("database/db.db")
    tarifes = db.query("SELECT * FROM tarifes")
    for tarif in tarifes:
        tarif = (tarif[1], tarif[2], tarif[3])
        tree.insert("", "end", values=tarif)
    def item_selected(event):
        for selected_item in tree.selection():
            item = tree.item(selected_item)
            tarif = item["values"][0]
        functions.enter_tarif(window, tarif)
    
    tree.bind("<<TreeviewSelect>>", item_selected)
    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_user_settings(window),
        relief="flat"
    )
    button_1.place(
        x=257.0,
        y=258.0,
        width=117.0,
        height=17.0
    )