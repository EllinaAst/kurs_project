from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame
import functions

def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame1/" + path


def open_admin_auth_window(window):
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 400,
        width = 400,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        200.0,
        200.0,
        image=image_image_1
    )

    image_image_2 = PhotoImage(
        file=relative_to_assets("image_2.png"))
    canvas.image_image_2 = image_image_2
    image_2 = canvas.create_image(
        206.0,
        300.0,
        image=image_image_2
    )
    canvas.create_rectangle(
        69.0,
        34.0,
        330.0,
        339.0,
        fill="#FFFFFF",
        outline="")

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.admin_authentificate(window, entry_1.get(), entry_2.get()),
        relief="flat"
    )
    button_1.place(
        x=90.0,
        y=278.0,
        width=219.0,
        height=37.0
    )

    canvas.create_text(
        131.0,
        55.0,
        anchor="nw",
        text="Вход в систему",
        fill="#000000",
        font=("SofiaSansSemiCondensed SemiBoldItalic", 20 * -1)
    )

    canvas.create_text(
        103.0,
        106.0,
        anchor="nw",
        text="Логин",
        fill="#000000",
        font=("OriginalSurfer Regular", 12 * -1)
    )

    canvas.create_text(
        108.0,
        158.0,
        anchor="nw",
        text="Пароль",
        fill="#000000",
        font=("OriginalSurfer Regular", 12 * -1)
    )

    entry_image_1 = PhotoImage(
        file=relative_to_assets("entry_1.png"))
    canvas.entry_image_1 = entry_image_1
    entry_bg_1 = canvas.create_image(
        205.5,
        134.5,
        image=entry_image_1
    )
    entry_1 = Entry(
        bd=0,
        bg="#CAEAEF",
        fg="#000716",
        highlightthickness=0
    )
    entry_1.place(
        x=113.0,
        y=124.0,
        width=185.0,
        height=19.0
    )

    entry_image_2 = PhotoImage(
        file=relative_to_assets("entry_2.png"))
    canvas.entry_image_2 = entry_image_2
    entry_bg_2 = canvas.create_image(
        205.5,
        186.5,
        image=entry_image_2
    )
    entry_2 = Entry(
        bd=0,
        bg="#CAEAEF",
        fg="#000716",
        highlightthickness=0
    )
    entry_2.place(
        x=113.0,
        y=176.0,
        width=185.0,
        height=19.0
    )

