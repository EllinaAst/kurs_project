from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame, ttk
import functions
from internal.database import DatabaseManager


def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame8/" + path

def open_admin_all_tarifes(window):
    window.geometry("400x285")
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 285,
        width = 400,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        139.99999999999756,
        21.000000000015913,
        image=image_image_1
    )

    image_image_2 = PhotoImage(
        file=relative_to_assets("image_2.png"))
    canvas.image_image_2 = image_image_2
    image_2 = canvas.create_image(
        356.0,
        22.0,
        image=image_image_2
    )

    columns = ("name", "price", "description")
    treeview_frame = Frame(frame)
    treeview_frame.place(x=0, y=43)
    tree = ttk.Treeview(treeview_frame, columns=columns, show="headings", selectmode="browse", height=7)
    tree.pack(side="left", fill="both")
    tree.heading("name", text="Название")
    tree.heading("price", text="Стоимость, руб/мес")
    tree.heading("description", text="Описание")
    tree.column("#1", width=126)
    tree.column("#2", width=126)
    tree.column("#3", width=126)
    scrollbar = ttk.Scrollbar(treeview_frame, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    db = DatabaseManager("database/db.db")
    tarifes = db.query("SELECT * FROM tarifes")
    for tarif in tarifes:
        tarif = (tarif[1], tarif[2], tarif[3])
        tree.insert("", "end", values=tarif)
    # def item_selected(event):
    #     for selected_item in tree.selection():
    #         item = tree.item(selected_item)
    #         tarif = item["values"][0]
    #     functions.enter_tarif(window, tarif)
    
    # tree.bind("<<TreeviewSelect>>", item_selected)

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_add_tarif_form(window),
        relief="flat"
    )
    button_1.place(
        x=239.0,
        y=225.0,
        width=154.0,
        height=26.0
    )

    button_image_2 = PhotoImage(
        file=relative_to_assets("button_2.png"))
    canvas.button_image_2 = button_image_2
    button_2 = Button(
        image=button_image_2,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_admin_settings(window),
        relief="flat"
    )
    button_2.place(
        x=257.0,
        y=258.0,
        width=117.0,
        height=17.0
    )

    button_image_3 = PhotoImage(
        file=relative_to_assets("button_3.png"))
    canvas.button_image_3 = button_image_3
    button_3 = Button(
        image=button_image_3,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: export_to_excel2(),
        relief="flat"
    )
    button_3.place(
        x=5.0,
        y=240.0,
        width=100.0,
        height=20.0
    )

import sqlite3
from openpyxl import Workbook
from tkinter import filedialog, messagebox

def export_to_excel2():
    """Exports data from the 'tarifes' table in db.db to an Excel file."""
    try:
        file_path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel Files", "*.xlsx"), ("All Files", "*.*")],
            title="Save File As"
        )

        if not file_path:
            return

        conn = sqlite3.connect(r"C:\Users\user\Desktop\2024.12.10_profi_tkinter_po1\database\db.db")
        cursor = conn.cursor()

        # Query the 'tarifes' table
        cursor.execute("""
            SELECT id, name, price, description
            FROM tarifes
        """)
        tarifes = cursor.fetchall()  # Correct variable name here

        if not tarifes:
            messagebox.showinfo("Information", "No data found to export.")
            conn.close()
            return

        wb = Workbook()
        ws = wb.active
        ws.title = "Tarifes"

        headers = ["id", "name", "price", "description"]
        ws.append(headers)

        for user in tarifes: # Corrected iteration variable
            ws.append(user)

        wb.save(file_path)
        conn.close()

        messagebox.showinfo("Успешно!", f"Данные экспортированы в {file_path}")

    except sqlite3.Error as e:
        messagebox.showerror("Ошибка!", f"Database error: {e}")
    except Exception as e:
        messagebox.showerror("Ошибка!", f"An error occurred: {e}")

