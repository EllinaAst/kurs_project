from pathlib import Path
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage, Frame
from internal.database import DatabaseManager
from tkinter.messagebox import showerror, showinfo
import functions


def relative_to_assets(path: str) -> str:
    return "./pages/assets/frame4/" + path

def open_user_settings_window(window):
    window.geometry("400x400")
    for widget in window.winfo_children():
        widget.destroy()
    frame = Frame(window)
    frame.pack(fill="both", expand=True)
    canvas = Canvas(
        frame,
        bg = "#FDFFFE",
        height = 400,
        width = 400,
        bd = 0,
        highlightthickness = 0,
        relief = "ridge"
    )

    canvas.place(x = 0, y = 0)
    image_image_1 = PhotoImage(
        file=relative_to_assets("image_1.png"))
    canvas.image_image_1 = image_image_1
    image_1 = canvas.create_image(
        139.9999999999975,
        21.00000000001591,
        image=image_image_1
    )

    canvas.create_text(
        7.0,
        75.0,
        anchor="nw",
        text="Ф.И.О.",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        3.0,
        107.0,
        anchor="nw",
        text="Номер телефона",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        8.0,
        139.0,
        anchor="nw",
        text="Адрес",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 15 * -1)
    )

    canvas.create_text(
        3.0,
        171.0,
        anchor="nw",
        text="Дата рождения",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    canvas.create_text(
        35.0,
        48.0,
        anchor="nw",
        text="Ваши данные:",
        fill="#000000",
        font=("Margarine Regular", 17 * -1)
    )

    canvas.create_rectangle(
        182.0,
        58.0,
        363.0,
        59.00000000000003,
        fill="#000000",
        outline="")

    entry_image_1 = PhotoImage(
        file=relative_to_assets("entry_1.png"))
    canvas.entry_image_1 = entry_image_1
    entry_bg_1 = canvas.create_image(
        221.5,
        89.5,
        image=entry_image_1
    )
    entry_1 = Entry(
        bd=0,
        bg="#B96F19",
        fg="#000716",
        highlightthickness=0
    )
    entry_1.place(
        x=73.0,
        y=79.0,
        width=297.0,
        height=19.0
    )

    entry_image_2 = PhotoImage(
        file=relative_to_assets("entry_2.png"))
    canvas.entry_image_2 = entry_image_2
    entry_bg_2 = canvas.create_image(
        262.5,
        120.5,
        image=entry_image_2
    )
    entry_2 = Entry(
        bd=0,
        bg="#B96F19",
        fg="#000716",
        highlightthickness=0
    )
    entry_2.place(
        x=155.0,
        y=110.0,
        width=215.0,
        height=19.0
    )

    entry_image_3 = PhotoImage(
        file=relative_to_assets("entry_3.png"))
    canvas.entry_image_3 = entry_image_3
    entry_bg_3 = canvas.create_image(
        218.0,
        150.5,
        image=entry_image_3
    )
    entry_3 = Entry(
        bd=0,
        bg="#B96F19",
        fg="#000716",
        highlightthickness=0
    )
    entry_3.place(
        x=66.0,
        y=140.0,
        width=304.0,
        height=19.0
    )

    entry_image_4 = PhotoImage(
        file=relative_to_assets("entry_4.png"))
    canvas.entry_image_4 = entry_image_4
    entry_bg_4 = canvas.create_image(
        257.0,
        181.5,
        image=entry_image_4
    )
    entry_4 = Entry(
        bd=0,
        bg="#B96F19",
        fg="#000716",
        highlightthickness=0
    )
    entry_4.place(
        x=144.0,
        y=171.0,
        width=226.0,
        height=19.0
    )

    image_image_2 = PhotoImage(
        file=relative_to_assets("image_2.png"))
    canvas.image_image_2 = image_image_2
    image_2 = canvas.create_image(
        356.0,
        22.0,
        image=image_image_2
    )

    canvas.create_rectangle(
        11.000001549720764,
        58.0,
        38.0,
        59.00000324989247,
        fill="#000000",
        outline="")

    canvas.create_text(
        35.0,
        212.0,
        anchor="nw",
        text="Тариф:",
        fill="#000000",
        font=("Margarine Regular", 17 * -1)
    )

    canvas.create_rectangle(
        182.0,
        222.0,
        363.0,
        223.0,
        fill="#000000",
        outline="")

    canvas.create_rectangle(
        11.000001549720764,
        222.0,
        38.0,
        223.00000324989247,
        fill="#000000",
        outline="")

    canvas.create_text(
        8.0,
        247.0,
        anchor="nw",
        text="Название тарифа",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 15 * -1)
    )

    canvas.create_text(
        7.0,
        276.0,
        anchor="nw",
        text="Стоимость ",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 16 * -1)
    )

    entry_image_5 = PhotoImage(
        file=relative_to_assets("entry_5.png"))
    canvas.entry_image_5 = entry_image_5
    entry_bg_5 = canvas.create_image(
        253.5,
        258.5,
        image=entry_image_5
    )
    entry_5 = Entry(
        bd=0,
        bg="#B96F19",
        fg="#000716",
        highlightthickness=0
    )
    entry_5.place(
        x=137.0,
        y=248.0,
        width=233.0,
        height=19.0
    )

    entry_image_6 = PhotoImage(
        file=relative_to_assets("entry_6.png"))
    canvas.entry_image_6 = entry_image_6
    entry_bg_6 = canvas.create_image(
        234.5,
        286.5,
        image=entry_image_6
    )
    entry_6 = Entry(
        bd=0,
        bg="#B96F19",
        fg="#000716",
        highlightthickness=0
    )
    entry_6.place(
        x=99.0,
        y=276.0,
        width=271.0,
        height=19.0
    )

    canvas.create_text(
        4.0,
        304.0,
        anchor="nw",
        text="Описание",
        fill="#000000",
        font=("PlayfairDisplay SemiBold", 15 * -1)
    )

    entry_image_7 = PhotoImage(
        file=relative_to_assets("entry_7.png"))
    canvas.entry_image_7 = entry_image_7
    entry_bg_7 = canvas.create_image(
        228.0,
        314.5,
        image=entry_image_7
    )
    entry_7 = Entry(
        bd=0,
        bg="#B96F19",
        fg="#000716",
        highlightthickness=0
    )
    entry_7.place(
        x=86.0,
        y=304.0,
        width=284.0,
        height=19.0
    )

    button_image_1 = PhotoImage(
        file=relative_to_assets("button_1.png"))
    canvas.button_image_1 = button_image_1
    button_1 = Button(
        image=button_image_1,
        borderwidth=0,
        highlightthickness=0,
        command=lambda: functions.show_all_tarifes(window),
        relief="flat"
    )
    button_1.place(
        x=258.0,
        y=356.0,
        width=119.0,
        height=23.0
    )

    db = DatabaseManager("database/db.db")
    user = db.query("SELECT * FROM users WHERE is_auth = 1 LIMIT 1")
    user_info = db.query(f"SELECT * FROM users_info WHERE user_id = {user[0][0]} LIMIT 1")
    tarif = db.query(f"SELECT * FROM tarifes WHERE id = {user_info[0][7]} LIMIT 1")
    entry_1.insert(0, user_info[0][2])
    entry_2.insert(0, user_info[0][3])
    entry_3.insert(0, user_info[0][4])
    entry_4.insert(0, user_info[0][5])
    entry_5.insert(0, tarif[0][1])
    entry_6.insert(0, tarif[0][2])
    entry_7.insert(0, tarif[0][3])



