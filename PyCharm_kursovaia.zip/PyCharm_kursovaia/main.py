from pages.start_page import open_auth_window
from tkinter import Tk

from internal.database import DatabaseManager


def deauth_all():
    db = DatabaseManager("database/db.db")
    db.execute("""
        UPDATE users
        SET is_auth = 0
    """, None)
deauth_all()

window = Tk()
window.geometry("400x400")
window.configure(bg = "#FDFFFE")

window.resizable(False, False)

open_auth_window(window)
window.mainloop()