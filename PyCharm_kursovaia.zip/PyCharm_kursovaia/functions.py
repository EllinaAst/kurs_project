from tkinter import Label
from tkinter.messagebox import showerror, showinfo

from internal.database import DatabaseManager

from pages.user_all_tarifes import open_user_all_tarifes
from pages.user_settings import open_user_settings_window
from pages.user_auth import open_user_auth_window
from pages.admin_auth import open_admin_auth_window
from pages.user_registration import open_user_registration_window
from pages.user_dayly_tarifes import open_user_dayly_tarifes
from pages.admin_settings import open_admin_settings
from pages.admin_tarifes import open_admin_all_tarifes
from pages.admin_tarif_add_form import open_admin_abonent_add_form
from pages.admin_abonents import open_admin_all_abonents
from pages.admin_abonent_find_form import open_admin_find_abonent_form




def enter_tarif(window, name):
    db = DatabaseManager("database/db.db")
    user = db.query("SELECT * FROM users WHERE is_auth = 1 LIMIT 1")
    if user:
        tarif = db.query(f"SELECT * FROM tarifes WHERE name = '{name}' LIMIT 1")
        db.execute(f"UPDATE users_info SET tarif_id = {tarif[0][0]} WHERE id = {user[0][0]}")
    open_user_settings_window(window)

def show_all_tarifes(window):
    open_user_all_tarifes(window)

def auth_as_user(window):
    open_user_auth_window(window)

def auth_as_admin(window):
    open_admin_auth_window(window)

def show_user_settings(window):
    open_user_settings_window(window)

def show_admin_settings(window):
    open_admin_settings(window)

def authentificate(window, login, password):
    if not all([login, password]):
        label = Label(text="Вы не заполнили необходимые поля")
        label.pack()
        return
    db = DatabaseManager("database/db.db")
    user = db.query(f"SELECT * FROM users WHERE login = '{login}'")
    if user:
        if user[0][2] == password:
            db.execute(f"UPDATE users SET is_auth = 1 WHERE login = '{login}'")
            show_user_settings(window)
        else:
            showerror(title="Информация", message="Пароль введен неверно!")
            return
    else:
        showerror(title="Информация", message="Пользователь не зарегистрирован!")
        return

def show_user_registration_window(window):
    open_user_registration_window(window)

def show_dayly_tarifes(window):
    open_user_dayly_tarifes(window)


def admin_authentificate(window, login, password):
    if not all([login, password]):
        showerror(title="Информация", message="Заполнены не все поля!")
        return
    db = DatabaseManager("database/db.db")
    admin = db.query(f"SELECT * FROM admins WHERE login = '{login}' LIMIT 1")
    if not admin:
        showerror(title="Информация", message="Админ не зарегистрирован!")
        return
    if admin[0][2] == password:
        db.execute(f"UPDATE admins SET is_auth = 1 WHERE login = '{login}'")
        show_admin_settings(window)
    else:
        showerror(title="Информация", message="Пароль введен неверно!")
        return
        

def show_all_abonents(window):
    open_admin_all_abonents(window)

def show_admin_all_tarifes(window):
    open_admin_all_tarifes(window)

def show_add_tarif_form(window):
    open_admin_abonent_add_form(window)

def show_find_abonent_form(window):
    open_admin_find_abonent_form(window)

def add_tarif(window, name, price, description):
    if not all([name, price, description]):
        showerror(title="Информация", message="Заполнены не все поля!")
        return
    db = DatabaseManager("database/db.db")
    db.execute(f"INSERT INTO tarifes (name, price, description) VALUES (?, ?, ?)", (name, price, description))
    showinfo(title="Информация", message="Тариф добавлен успешно!")
    show_admin_settings(window)

