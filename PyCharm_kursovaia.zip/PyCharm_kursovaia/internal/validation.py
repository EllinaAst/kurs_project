import re
from datetime import datetime
def validate_phone(phone_number):
    return True if re.match(r'^\+\d{11,}$', phone_number) else False

def validate_email(email_address):
    return True if re.match(r'^[\w.-]+@[\w]+\.[a-zA-Z]{2,}', email_address) else False

def validate_birthday(birthday):
    try:
        birth_date = datetime.strptime(birthday, "%d.%m.%Y")
        return True
    except ValueError:
        return False